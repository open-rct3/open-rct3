using System;
using System.Drawing;
using System.Windows.Forms;

/// <summary>
/// A drop-in replacement for MessageBox that supports custom button labels.
/// Matches system MessageBox appearance using SystemIcons and SystemColors.
/// </summary>
public partial class CustomMessageBox : Form
{
    // -------------------------------------------------------------------------
    // Result enum — mirrors DialogResult for the three buttons
    // -------------------------------------------------------------------------
    public enum CustomDialogResult { Abort, Retry, Ignore }

    // -------------------------------------------------------------------------
    // Private state
    // -------------------------------------------------------------------------
    private CustomDialogResult _result = CustomDialogResult.Ignore;

    // -------------------------------------------------------------------------
    // Constructor (called by designer; use Show() factory methods externally)
    // -------------------------------------------------------------------------
    public CustomMessageBox()
    {
        InitializeComponent();
    }

    // =========================================================================
    // Public factory methods
    // =========================================================================

    /// <summary>
    /// Shows a dialog with Abort / Restart / Ignore buttons and a system icon.
    /// </summary>
    /// <param name="message">The message to display.</param>
    /// <param name="caption">The window title.</param>
    /// <param name="icon">Which system icon to show (use MessageBoxIcon values).</param>
    /// <param name="owner">Optional owner window.</param>
    /// <returns>Which button the user clicked.</returns>
    public static CustomDialogResult Show(
        string message,
        string caption,
        MessageBoxIcon icon = MessageBoxIcon.None,
        IWin32Window owner = null)
    {
        using var dlg = new CustomMessageBox();
        dlg.Configure(message, caption, icon);

        if (owner != null)
            dlg.ShowDialog(owner);
        else
            dlg.ShowDialog();

        return dlg._result;
    }

    // =========================================================================
    // Internal configuration
    // =========================================================================

    private void Configure(string message, string caption, MessageBoxIcon icon)
    {
        Text = caption;
        labelMessage.Text = message;
        pictureBoxIcon.Image = GetSystemIcon(icon)?.ToBitmap();
        pictureBoxIcon.Visible = pictureBoxIcon.Image != null;

        AutoSizeToContent();
    }

    /// <summary>
    /// Maps MessageBoxIcon to a SystemIcons entry (identical to what MessageBox uses).
    /// </summary>
    private static Icon GetSystemIcon(MessageBoxIcon icon) => icon switch
    {
        MessageBoxIcon.Error       => SystemIcons.Error,
        MessageBoxIcon.Warning     => SystemIcons.Warning,
        MessageBoxIcon.Information => SystemIcons.Information,
        MessageBoxIcon.Question    => SystemIcons.Question,
        _                          => null,
    };

    /// <summary>
    /// Adjusts the form height so the message label is never clipped.
    /// Accounts for newlines and text wrapping within the label's fixed width.
    /// </summary>
    private void AutoSizeToContent()
    {
        // Measure how tall the text actually needs to be inside the label's width
        using var g = labelMessage.CreateGraphics();
        var textSize = g.MeasureString(
            labelMessage.Text,
            labelMessage.Font,
            labelMessage.Width);

        int requiredLabelHeight = (int)Math.Ceiling(textSize.Height);
        int minLabelHeight = labelMessage.MinimumSize.Height;
        int newLabelHeight = Math.Max(requiredLabelHeight, minLabelHeight);

        int delta = newLabelHeight - labelMessage.Height;
        if (delta != 0)
        {
            labelMessage.Height += delta;
            Height += delta;
        }
    }

    // =========================================================================
    // Button event handlers
    // =========================================================================

    private void buttonAbort_Click(object sender, EventArgs e)
    {
        _result = CustomDialogResult.Abort;
        Close();
    }

    private void buttonRetry_Click(object sender, EventArgs e)
    {
        _result = CustomDialogResult.Retry;
        Close();
    }

    private void buttonIgnore_Click(object sender, EventArgs e)
    {
        _result = CustomDialogResult.Ignore;
        Close();
    }
}
