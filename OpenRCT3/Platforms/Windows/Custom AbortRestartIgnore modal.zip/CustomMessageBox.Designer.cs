partial class CustomMessageBox
{
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
            components.Dispose();
        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support — do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        this.tableLayoutOuter   = new System.Windows.Forms.TableLayoutPanel();
        this.pictureBoxIcon     = new System.Windows.Forms.PictureBox();
        this.labelMessage       = new System.Windows.Forms.Label();
        this.panelButtons       = new System.Windows.Forms.Panel();
        this.buttonIgnore       = new System.Windows.Forms.Button();
        this.buttonRetry        = new System.Windows.Forms.Button();
        this.buttonAbort        = new System.Windows.Forms.Button();

        this.tableLayoutOuter.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIcon)).BeginInit();
        this.panelButtons.SuspendLayout();
        this.SuspendLayout();

        // ------------------------------------------------------------------
        // tableLayoutOuter  (icon | message)
        // ------------------------------------------------------------------
        this.tableLayoutOuter.Anchor =
            System.Windows.Forms.AnchorStyles.Top |
            System.Windows.Forms.AnchorStyles.Left |
            System.Windows.Forms.AnchorStyles.Right;
        this.tableLayoutOuter.ColumnCount = 2;
        this.tableLayoutOuter.ColumnStyles.Add(
            new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 54F));
        this.tableLayoutOuter.ColumnStyles.Add(
            new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
        this.tableLayoutOuter.Controls.Add(this.pictureBoxIcon, 0, 0);
        this.tableLayoutOuter.Controls.Add(this.labelMessage,   1, 0);
        this.tableLayoutOuter.Location = new System.Drawing.Point(12, 12);
        this.tableLayoutOuter.Name     = "tableLayoutOuter";
        this.tableLayoutOuter.RowCount = 1;
        this.tableLayoutOuter.RowStyles.Add(
            new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
        this.tableLayoutOuter.Size    = new System.Drawing.Size(380, 70);
        this.tableLayoutOuter.TabIndex = 0;

        // ------------------------------------------------------------------
        // pictureBoxIcon
        // ------------------------------------------------------------------
        this.pictureBoxIcon.Location  = new System.Drawing.Point(3, 3);
        this.pictureBoxIcon.Name      = "pictureBoxIcon";
        this.pictureBoxIcon.Size      = new System.Drawing.Size(48, 48);
        this.pictureBoxIcon.SizeMode  = System.Windows.Forms.PictureBoxSizeMode.Zoom;
        this.pictureBoxIcon.TabIndex  = 0;
        this.pictureBoxIcon.TabStop   = false;

        // ------------------------------------------------------------------
        // labelMessage
        // ------------------------------------------------------------------
        this.labelMessage.Dock        = System.Windows.Forms.DockStyle.Fill;
        this.labelMessage.Location    = new System.Drawing.Point(57, 0);
        this.labelMessage.MinimumSize = new System.Drawing.Size(0, 54);
        this.labelMessage.Name        = "labelMessage";
        this.labelMessage.Padding     = new System.Windows.Forms.Padding(0, 4, 0, 0);
        this.labelMessage.Size        = new System.Drawing.Size(320, 70);
        this.labelMessage.TabIndex    = 1;
        this.labelMessage.Text        = "";
        this.labelMessage.TextAlign   = System.Drawing.ContentAlignment.MiddleLeft;

        // ------------------------------------------------------------------
        // panelButtons  (bottom strip)
        // ------------------------------------------------------------------
        this.panelButtons.Anchor =
            System.Windows.Forms.AnchorStyles.Bottom |
            System.Windows.Forms.AnchorStyles.Left   |
            System.Windows.Forms.AnchorStyles.Right;
        this.panelButtons.BackColor  = System.Drawing.SystemColors.Control;
        this.panelButtons.Controls.Add(this.buttonIgnore);
        this.panelButtons.Controls.Add(this.buttonRetry);
        this.panelButtons.Controls.Add(this.buttonAbort);
        this.panelButtons.Location   = new System.Drawing.Point(0, 98);
        this.panelButtons.Name       = "panelButtons";
        this.panelButtons.Size       = new System.Drawing.Size(404, 46);
        this.panelButtons.TabIndex   = 1;

        // ------------------------------------------------------------------
        // buttonIgnore
        // ------------------------------------------------------------------
        this.buttonIgnore.Anchor   =
            System.Windows.Forms.AnchorStyles.Top |
            System.Windows.Forms.AnchorStyles.Right;
        this.buttonIgnore.Location = new System.Drawing.Point(317, 10);
        this.buttonIgnore.Name     = "buttonIgnore";
        this.buttonIgnore.Size     = new System.Drawing.Size(75, 26);
        this.buttonIgnore.TabIndex = 2;
        this.buttonIgnore.Text     = "&Ignore";
        this.buttonIgnore.UseVisualStyleBackColor = true;
        this.buttonIgnore.Click  += new System.EventHandler(this.buttonIgnore_Click);

        // ------------------------------------------------------------------
        // buttonRetry  — labelled "Restart"
        // ------------------------------------------------------------------
        this.buttonRetry.Anchor   =
            System.Windows.Forms.AnchorStyles.Top |
            System.Windows.Forms.AnchorStyles.Right;
        this.buttonRetry.Location = new System.Drawing.Point(236, 10);
        this.buttonRetry.Name     = "buttonRetry";
        this.buttonRetry.Size     = new System.Drawing.Size(75, 26);
        this.buttonRetry.TabIndex = 1;
        this.buttonRetry.Text     = "&Restart";          // <-- renamed here
        this.buttonRetry.UseVisualStyleBackColor = true;
        this.buttonRetry.Click   += new System.EventHandler(this.buttonRetry_Click);

        // ------------------------------------------------------------------
        // buttonAbort
        // ------------------------------------------------------------------
        this.buttonAbort.Anchor   =
            System.Windows.Forms.AnchorStyles.Top |
            System.Windows.Forms.AnchorStyles.Right;
        this.buttonAbort.Location = new System.Drawing.Point(155, 10);
        this.buttonAbort.Name     = "buttonAbort";
        this.buttonAbort.Size     = new System.Drawing.Size(75, 26);
        this.buttonAbort.TabIndex = 0;
        this.buttonAbort.Text     = "&Abort";
        this.buttonAbort.UseVisualStyleBackColor = true;
        this.buttonAbort.Click   += new System.EventHandler(this.buttonAbort_Click);

        // ------------------------------------------------------------------
        // CustomMessageBox (Form)
        // ------------------------------------------------------------------
        this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
        this.AutoScaleMode       = System.Windows.Forms.AutoScaleMode.Font;
        this.ClientSize          = new System.Drawing.Size(404, 144);
        this.Controls.Add(this.tableLayoutOuter);
        this.Controls.Add(this.panelButtons);
        this.FormBorderStyle     = System.Windows.Forms.FormBorderStyle.FixedDialog;
        this.MaximizeBox         = false;
        this.MinimizeBox         = false;
        this.Name                = "CustomMessageBox";
        this.ShowInTaskbar       = false;
        this.StartPosition       = System.Windows.Forms.FormStartPosition.CenterParent;

        this.tableLayoutOuter.ResumeLayout(false);
        ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIcon)).EndInit();
        this.panelButtons.ResumeLayout(false);
        this.ResumeLayout(false);
    }

    #endregion

    // Designer-owned controls
    private System.Windows.Forms.TableLayoutPanel tableLayoutOuter;
    private System.Windows.Forms.PictureBox       pictureBoxIcon;
    private System.Windows.Forms.Label            labelMessage;
    private System.Windows.Forms.Panel            panelButtons;
    private System.Windows.Forms.Button           buttonAbort;
    private System.Windows.Forms.Button           buttonRetry;   // shows as "Restart"
    private System.Windows.Forms.Button           buttonIgnore;
}
